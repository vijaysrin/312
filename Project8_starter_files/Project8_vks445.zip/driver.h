
#include <stdio.h>
#include <stdlib.h>
#include "Parse.h"
#include <string>
#include <iostream>
#include <unordered_map>

using namespace std;

//inline unordered_map<string, int> map;

void run();

