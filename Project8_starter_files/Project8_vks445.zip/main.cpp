#include "driver.h"


int main(void){
    set_input("test2.blip");
    run();
}